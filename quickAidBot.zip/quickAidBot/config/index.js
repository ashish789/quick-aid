var config={
    "port":9000,
    "dbPort":27017,
    "dbHost":"localhost",
    "dbName":"quickbot",
    "sessionStore":{
	"store":"mongoStore",
	"uri":"mongodb://127.0.0.1:27017/user",
	"secret":'123, easy as ABC. ABC, easy as 123'//optional only use for memcached
	},
}

module.exports=config;