var ambulance=require('../database/ambulance.js');
var appointments=require('../database/appointments.js');

exports.renderHomePage = function(req,res,next){
    
  res.render('index', { title: 'QuickBot' });   
    
}
exports.getAppoinments = function(req,res,next){
    var deptName = req.params.deptType;
    var dateApp = req.params.aptDate;
    
    appointments.find({"dept_name": deptName, "startdate": { $gt: new Date(dateApp), $lt: new Date("2017-02-24T12:44:32.905Z") }},function(err,data){
        console.log(data)
         if(err){
                     res.status(500).send(err);
               }
               else{
                       res.send(data);
               }
    })

}

exports.addppoinments = function(req,res,next){

var appointment = new appointments(req.body.appObj);
   appointment.save(function(err,data){
        console.log(data)
         if(err){
                     res.status(500).send(err);
               }
               else{
                       res.send("success");
               }
    })


}