var mongoose = require('./index.js');
var Schema = mongoose.Schema;

var ambulanceSchema = new Schema({
  id:Number,
  driver_name:String,
  status:String,
  phone:Number
 
});
var Ambulance = mongoose.model('Ambulance', ambulanceSchema);
module.exports=Ambulance;