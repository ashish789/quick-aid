var express = require('express');
var router = express.Router();
var BaseController = require('../controllers/BaseController')

/* GET home page. */
router.get('/', function(req, res, next) {
    
    BaseController.renderHomePage(req, res, next);
 
});

router.get('/appointment/:deptType/:aptDate', function(req, res, next) {
    
    BaseController.getAppoinments(req, res, next);
 
});

router.post('/addAppointment', function(req, res, next) {
    
    var obj = {
        appointment_id : 10,
        patient : "darshan",
        startdate : new Date(),
        enddate : new Date(),
        examinationRoom : "",
        disease:"fever",
        status:"Booked",
        doc_id:1,
        dept_name:"General"}
    req.body.appObj = obj;
    BaseController.addppoinments(req, res, next);
 
});

module.exports = router;
