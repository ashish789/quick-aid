var express=require('express');
var router=express.Router();
var user=require('../database/user.js');
var roles=require('../database/roles.js');
var loginController=require('../controller/loginController.js');
var createRoleController=require('../controller/createRoleController.js');
var searchRoleController=require('../controller/searchRoleController.js');

router.use('/test',function(req,res,next){
    res.json({message:"this is dummy api call"});
});
router.get('/login',loginController.renderLogin);
router.post('/login',loginController.login);
router.post('/roles',createRoleController.submitPolicy);
router.get('/roles',function(req,res,next){

       
    roles.find({},function(err,data){
         if(err){
                     res.status(500).send(err);
               }
               else{
                       res.send(data);
               }
    })
});
router.get('/roles/:key',function(req,res,next){

       
    roles.find({"roleKey":req.params.key},function(err,data){
         if(err){
                     res.status(500).send(err);
               }
               else{
                       res.send(data);
               }
    })
});
router.put('/roles/:key',function(req,res,next){
     var data={}
     if(req.body.rolename){
          data.name=req.body.rolename;
     }
    if(req.body.desc){
         data.description=req.body.desc;
    }
    if(req.body.appInstances){
        data.appInstances=req.body.appInstances;
    }
    if(req.body.entitlements){
        data.entitlements=req.body.entitlements;
    }
    if(req.body.roleKey){
        data.roleKey=req.body.roleKey;
    }
    var update={$set:data}
       
    roles.findOneAndUpdate({"roleKey":req.params.key},update,function(err,data){
         if(err){
                     res.status(500).send(err);
               }
               else{
                       res.send(data);
               }
    })
});
router.get('/appInstances',createRoleController.getAppInstances);
router.get('/entitlements',createRoleController.getEntitlements);
router.post('/getRoles',searchRoleController.getRoles);
router.post('/removeApp',function(req,res,next){
                    var app=req.body.app;
                    var index=0;
                    req.session.appInstanceList.map(function(data){
                                 if(data.appName==app){
                                    return index;
                                 }
                                 index++;
                    });
                    req.session.appInstanceList=req.session.appInstanceList.splice(index,1);
                    res.send("success")

});
module.exports=router;